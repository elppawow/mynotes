let b = 2
const c = () => b + 1