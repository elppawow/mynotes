let a = 1
console.log(a)