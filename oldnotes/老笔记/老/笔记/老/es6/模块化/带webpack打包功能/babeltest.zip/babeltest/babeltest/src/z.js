// 案例一
// import c1 from "./c1"
// let jspang= new c1
// jspang.name('jspang')

// 案例二
// import {Coder, a} from "./c1"
// let jspang= new Coder
// jspang.name('jspang')
// console.log(a)

// 案例三
import c1 from "./c1"
let Cc = new c1.Clas
Cc.ce()
console.log(c1.age)
c1.f()
